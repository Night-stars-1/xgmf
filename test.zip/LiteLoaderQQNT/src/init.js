const { ipcMain, shell } = require("electron");
const path = require("node:path");
const fs = require("node:fs");


const root_path = path.join(__dirname, "..");
const data_path = path.join(root_path, "data");
const plugins_path = path.join(root_path, "plugins");

const config = require(path.join(root_path, "config.json"));
const liteloader_package = require(path.join(root_path, "package.json"));
const qqnt_package = require(path.join(process.resourcesPath, "app/package.json"))


function disablePlugin(slug, disabled) {
    const config_path = path.join(root_path, "config.json");
    const config = JSON.parse(fs.readFileSync(config_path, "utf-8"));
    if (disabled) {
        config.LiteLoader.disabled_plugins = config.LiteLoader.disabled_plugins.concat(slug);
    } else {
        config.LiteLoader.disabled_plugins = config.LiteLoader.disabled_plugins.filter(item => item != slug);
    }
    fs.writeFileSync(config_path, JSON.stringify(config, null, 4), "utf-8");
}


function getConfig(slug, default_config) {
    let config = {};
    const config_path = path.join(data_path, slug, "config.json");
    fs.mkdirSync(path.dirname(config_path), { recursive: true });
    if (fs.existsSync(config_path)) {
        config = JSON.parse(fs.readFileSync(config_path, "utf-8"));
    } else {
        fs.writeFileSync(config_path, JSON.stringify(default_config, null, 4), "utf-8");
    }
    return Object.assign({}, default_config, config);
}


function setConfig(slug, new_config) {
    const config_path = path.join(data_path, slug, "config.json");
    fs.mkdirSync(path.dirname(config_path), { recursive: true });
    fs.writeFileSync(config_path, JSON.stringify(new_config, null, 4), "utf-8");
}


const LiteLoader = {
    path: {
        root: root_path,
        data: data_path,
        plugins: plugins_path
    },
    versions: {
        qqnt: qqnt_package.version,
        liteloader: liteloader_package.version,
        node: process.versions.node,
        chrome: process.versions.chrome,
        electron: process.versions.electron
    },
    os: {
        platform: process.platform
    },
    package: {
        liteloader: liteloader_package,
        qqnt: qqnt_package
    },
    config: config,
    plugins: {},
    api: {
        disablePlugin: disablePlugin,
        config: {
            set: setConfig,
            get: getConfig
        },
        openExternal: shell.openExternal
    }
};


// 将LiteLoader对象挂载到全局
Object.defineProperty(globalThis, "LiteLoader", {
    configurable: false,
    get() {
        const stack = new Error().stack.split("\n");
        if (stack[2].includes(LiteLoader.path.root)) {
            return LiteLoader;
        }
    }
});


// 将LiteLoader对象挂载到window
ipcMain.on("LiteLoader.LiteLoader.LiteLoader", (event) => {
    event.returnValue = {
        ...LiteLoader,
        api: void null
    }
});

ipcMain.handle("LiteLoader.LiteLoader.api", (event, name, method, ...args) => {
    if (name == "disablePlugin") {
        if (method == "disablePlugin") {
            return LiteLoader.api.disablePlugin(...args);
        }
    }
    if (name == "config") {
        if (method == "get") {
            return LiteLoader.api.config.get(...args);
        }
        if (method == "set") {
            return LiteLoader.api.config.set(...args);
        }
    }
    if (name == "openExternal") {
        if (method == "openExternal") {
            return LiteLoader.api.openExternal(...args);
        }
    }
});


// LiteLoader的控制台输出
Object.defineProperty(global, "output", {
    configurable: false,
    value: (...args) => console.log("\x1b[32m%s\x1b[0m", "[LiteLoader]", ...args)
});


require("./main.js");
